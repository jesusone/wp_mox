<?php
/**
 * Add row params
 * 
 * @author Fox
 * @since 1.0.0
 */


    vc_add_param("vc_tta_section", array(
        "type" => "colorpicker",
        "class" => "",
        "heading" => __('Tab Color', 'creativ'),
        "param_name" => "tab_color",
        "description" => '',
         "value" => "#03acdc"
    ));

